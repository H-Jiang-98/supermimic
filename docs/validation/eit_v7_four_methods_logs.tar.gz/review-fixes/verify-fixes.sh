set -e
root=$PWD
previous=/tmp/eit-v7-four-methods.aLONzkEs
envroot=/mnt/cpfs/zbl-cpfs-new/USERS/leojiang/supermimic_ws
source "$envroot/env.sh"
export PYTHONPATH="$root/src:$root"
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=7 PYTORCH_JIT=0 CUBLAS_WORKSPACE_CONFIG=:4096:8
export WANDB_MODE=offline WANDB_DIR="$root" WANDB_CACHE_DIR="$previous/wandb-cache" WANDB_DATA_DIR="$previous/wandb-data"
export OMP_NUM_THREADS=1 PYTHONUNBUFFERED=1 TORCHINDUCTOR_COMPILE_THREADS=2
if [[ -n "$(nvidia-smi -i 7 --query-compute-apps=pid --format=csv,noheader,nounits)" ]]; then exit 3; fi
read -r used < "$previous/elapsed"
remaining=$((585-used-1))
if ((remaining > 120)); then remaining=120; fi
if ((remaining < 1)); then exit 124; fi
begin=$(date +%s)
set +e
timeout -k 5 "$remaining" python check.py > "$root/result.log" 2>&1
status=$?
end=$(date +%s)
total=$((used+end-begin+1))
printf '%s\n' "$total" > "$previous/elapsed"
printf 'review-fixes %s status %s cumulative seconds %s\n' "$(date -Iseconds)" "$status" "$total" >> "$previous/budget.log"
printf 'status=%s cumulative=%s\n' "$status" "$total"
tail -18 "$root/result.log"
nvidia-smi -i 7 --query-compute-apps=pid --format=csv,noheader,nounits
exit "$status"
