set -e
root=$PWD
previous=/tmp/eit-v7-four-methods.aLONzkEs
envroot=/mnt/cpfs/zbl-cpfs-new/USERS/leojiang/supermimic_ws
source "$envroot/env.sh"
export PYTHONPATH="$root/src:$root"
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=7 PYTORCH_JIT=0 CUBLAS_WORKSPACE_CONFIG=:4096:8
export WANDB_MODE=offline OMP_NUM_THREADS=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
if [[ -n "$(nvidia-smi -i 7 --query-compute-apps=pid --format=csv,noheader,nounits)" ]]; then exit 3; fi
read -r used < "$previous/elapsed"
remaining=$((457+120-used-1))
if ((remaining < 1)); then exit 124; fi
begin=$(date +%s)
set +e
timeout -k 5 "$remaining" python -m pytest -v --tb=short -x tests/test_estimator_eit_graph.py -k 'baseline_prepared_reset or baseline_replay_posterior_independence' > frame-checks.log 2>&1
status=$?
end=$(date +%s)
total=$((used+end-begin+1))
printf '%s\n' "$total" > "$previous/elapsed"
printf 'frame-checks %s status %s cumulative seconds %s\n' "$(date -Iseconds)" "$status" "$total" >> "$previous/budget.log"
printf 'status=%s cumulative=%s\n' "$status" "$total"
tail -18 frame-checks.log
nvidia-smi -i 7 --query-compute-apps=pid --format=csv,noheader,nounits
exit "$status"
