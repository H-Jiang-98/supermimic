import os
from pathlib import Path
import sys
import pytest

root = Path.cwd()
os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
tests = [
    "tests/test_estimator_eit_graph.py::test_baseline_prepared_reset_and_step_match_tensor_rollout",
    "tests/test_estimator_eit_graph.py::test_compiled_baseline_graph_matches_eager",
    "tests/test_estimator_eit_launch.py",
    "tests/test_estimator_eit_training.py",
    "tests/test_estimator_world_model_env.py",
]
status = pytest.main(["-q", "--tb=short", "-x", *tests])
if status:
    sys.exit(status)
from supermimic.scripts import check_eit_four_methods
sys.argv = ["check_eit_four_methods", "--output", str(root / "smoke")]
check_eit_four_methods.main()
