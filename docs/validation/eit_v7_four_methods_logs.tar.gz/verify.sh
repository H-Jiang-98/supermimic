#!/usr/bin/env bash
set -euo pipefail
cd /tmp/eit-v7-four-methods.aLONzkEs
root=$PWD
envroot=/mnt/cpfs/zbl-cpfs-new/USERS/leojiang/supermimic_ws
source "$envroot/env.sh"
export PYTHONPATH="$root/src:$root"
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=7
export WANDB_MODE=offline WANDB_DATA_DIR="$root/wandb-data" WANDB_CACHE_DIR="$root/wandb-cache" WANDB_DIR="$root"
export OMP_NUM_THREADS=1 PYTORCH_JIT=0 CUBLAS_WORKSPACE_CONFIG=:4096:8
export PYTHONUNBUFFERED=1 TORCHINDUCTOR_COMPILE_THREADS=2
gpu_info() { nvidia-smi -i "$CUDA_VISIBLE_DEVICES" --query-gpu=index,uuid,memory.used,utilization.gpu --format=csv,noheader,nounits; }
gpu_info
if [[ -n "$(nvidia-smi -i "$CUDA_VISIBLE_DEVICES" --query-compute-apps=pid --format=csv,noheader,nounits)" ]]; then
  echo "Selected GPU is in use"
  exit 1
fi
used=0
if [[ -f elapsed ]]; then read -r used < elapsed; fi
remaining=$((465-used))
if ((remaining<=0)); then exit 124; fi
begin=$(date +%s)
printf 'start %s, previous seconds %s, remaining %s\n' "$(date -Iseconds)" "$used" "$remaining" | tee -a budget.log
set +e
timeout -k 5 "$remaining" bash -e -c '
  for phase in "$@"; do
    case "$phase" in
      smoke) python -m supermimic.scripts.check_eit_four_methods --output "smoke-$(date +%s)" > "smoke-$(date +%s).log" 2>&1 ;;
      isolation) python -m pytest -v --tb=short tests/test_estimator_eit_graph.py -k baseline_replay_posterior_independence > isolation.log 2>&1 ;;
      graphs) python -m pytest -v --tb=short tests/test_estimator_eit_graph.py -k compiled_baseline_graph_matches_eager > graphs.log 2>&1 ;;
      regression) python -m pytest -q --tb=short tests/test_estimator_eit_launch.py tests/test_estimator_eit_training.py > regression.log 2>&1 ;;
    esac
    echo "PASS $phase"
  done
' eit-check "$@"
status=$?
set -e
end=$(date +%s)
echo $((used+end-begin+1)) > elapsed
printf 'end %s, exit %s, cumulative seconds %s\n' "$(date -Iseconds)" "$status" "$(cat elapsed)" | tee -a budget.log
gpu_info
exit "$status"
